package sample.fifa.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import sample.fifa.entities.Player_defense;
import java.util.List;

@Repository
public interface Player_defenseRepository extends JpaRepository<Player_defense, Integer> {
    public Player_defense findById(int id);

    public List<Player_defense> findByTackles(int tackles);

    // public List<Player_defense> findByTackles_wonGreaterThanEqual(int
    // tackles_won);
    // public List<Player_defense> findByPosition(String position);

    // public List<Player_defense> findByTeam(String team);

}
