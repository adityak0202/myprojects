package sample.fifa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FifaApplication {
	public static void main(String[] args) {
		SpringApplication.run(FifaApplication.class, args);
	}
}
