package sample.fifa.dao;

import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import sample.fifa.entities.Player_stats;
import java.util.List;

@Repository
public interface Player_statsRepository extends JpaRepository<Player_stats, Integer> {
    public Player_stats findById(int id);

    public List<Player_stats> findByGoalsGreaterThanEqual(int goals);;

    public List<Player_stats> findByGamesGreaterThanEqual(int games);
}
