package sample.fifa.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "player_stats")
public class Player_stats {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String player;
    private String position;
    private String team;
    private String age;
    private String club;
    private int birth_year;
    private int games;
    private int games_starts;
    private int minutes;
    private double minutes_90s;
    private int goals;
    private int assists;
    private int goals_pens;
    private int pens_made;
    private int pens_att;
    private int cards_yellow;
    private int cards_red;
    private double goals_per90;
    private double assists_per90;
    private double goals_assists_per90;
    private double goals_pens_per90;
    private double goals_assists_pens_per90;
    private double xg;
    private double npxg;
    private double xg_assist;
    private double npxg_xg_assist;
    private double xg_per90;
    private double xg_assist_per90;
    private double xg_xg_assist_per90;
    private double npxg_per90;
    private double npxg_xg_assist_per90;

    @Override
    public String toString() {
        return "Player_stats [id=" + id + ", player=" + player + ", position=" + position + ", team=" + team + ", age="
                + age + ", club=" + club + ", birth_year=" + birth_year + ", games=" + games + ", games_starts="
                + games_starts + ", minutes=" + minutes + ", minutes_90s=" + minutes_90s + ", goals=" + goals
                + ", assists=" + assists + ", goals_pens=" + goals_pens + ", pens_made=" + pens_made + ", pens_att="
                + pens_att + ", cards_yellow=" + cards_yellow + ", cards_red=" + cards_red + ", goals_per90="
                + goals_per90 + ", assists_per90=" + assists_per90 + ", goals_assists_per90=" + goals_assists_per90
                + ", goals_pens_90=" + goals_pens_per90 + ", goals_assists_pens_per90=" + goals_assists_pens_per90
                + ", xg=" + xg + ", npxg=" + npxg + ", xg_assist=" + xg_assist + ", npxg_assist=" + npxg_xg_assist
                + ", xg_per90=" + xg_per90 + ", xg_assist_per90=" + xg_assist_per90 + ", xg_xg_assist_per90="
                + xg_xg_assist_per90 + ", npxg_per90=" + npxg_per90 + ", npxg_xg_assist_per_90=" + npxg_xg_assist_per90
                + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getClub() {
        return club;
    }

    public void setClub(String club) {
        this.club = club;
    }

    public int getBirth_year() {
        return birth_year;
    }

    public void setBirth_year(int birth_year) {
        this.birth_year = birth_year;
    }

    public int getGames() {
        return games;
    }

    public void setGames(int games) {
        this.games = games;
    }

    public int getGames_starts() {
        return games_starts;
    }

    public void setGames_starts(int games_starts) {
        this.games_starts = games_starts;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    public double getMinutes_90s() {
        return minutes_90s;
    }

    public void setMinutes_90s(double minutes_90s) {
        this.minutes_90s = minutes_90s;
    }

    public int getGoals() {
        return goals;
    }

    public void setGoals(int goals) {
        this.goals = goals;
    }

    public int getAssists() {
        return assists;
    }

    public void setAssists(int assists) {
        this.assists = assists;
    }

    public int getGoals_pens() {
        return goals_pens;
    }

    public void setGoals_pens(int goals_pens) {
        this.goals_pens = goals_pens;
    }

    public int getPens_made() {
        return pens_made;
    }

    public void setPens_made(int pens_made) {
        this.pens_made = pens_made;
    }

    public int getPens_att() {
        return pens_att;
    }

    public void setPens_att(int pens_att) {
        this.pens_att = pens_att;
    }

    public int getCards_yellow() {
        return cards_yellow;
    }

    public void setCards_yellow(int cards_yellow) {
        this.cards_yellow = cards_yellow;
    }

    public int getCards_red() {
        return cards_red;
    }

    public void setCards_red(int cards_red) {
        this.cards_red = cards_red;
    }

    public double getGoals_per90() {
        return goals_per90;
    }

    public void setGoals_per90(double goals_per90) {
        this.goals_per90 = goals_per90;
    }

    public double getAssists_per90() {
        return assists_per90;
    }

    public void setAssists_per90(double assists_per90) {
        this.assists_per90 = assists_per90;
    }

    public double getGoals_assists_per90() {
        return goals_assists_per90;
    }

    public void setGoals_assists_per90(double goals_assists_per90) {
        this.goals_assists_per90 = goals_assists_per90;
    }

    public double getGoals_pens_90() {
        return goals_pens_per90;
    }

    public void setGoals_pens_90(double goals_pens_90) {
        this.goals_pens_per90 = goals_pens_90;
    }

    public double getGoals_assists_pens_per90() {
        return goals_assists_pens_per90;
    }

    public void setGoals_assists_pens_per90(double goals_assists_pens_per90) {
        this.goals_assists_pens_per90 = goals_assists_pens_per90;
    }

    public double getXg() {
        return xg;
    }

    public void setXg(double xg) {
        this.xg = xg;
    }

    public double getNpxg() {
        return npxg;
    }

    public void setNpxg(double npxg) {
        this.npxg = npxg;
    }

    public double getXg_assist() {
        return xg_assist;
    }

    public void setXg_assist(double xg_assist) {
        this.xg_assist = xg_assist;
    }

    public double getNpxg_assist() {
        return npxg_xg_assist;
    }

    public void setNpxg_assist(double npxg_assist) {
        this.npxg_xg_assist = npxg_assist;
    }

    public double getXg_per90() {
        return xg_per90;
    }

    public void setXg_per90(double xg_per90) {
        this.xg_per90 = xg_per90;
    }

    public double getXg_assist_per90() {
        return xg_assist_per90;
    }

    public void setXg_assist_per90(double xg_assist_per90) {
        this.xg_assist_per90 = xg_assist_per90;
    }

    public double getXg_xg_assist_per90() {
        return xg_xg_assist_per90;
    }

    public void setXg_xg_assist_per90(double xg_xg_assist_per90) {
        this.xg_xg_assist_per90 = xg_xg_assist_per90;
    }

    public double getNpxg_per90() {
        return npxg_per90;
    }

    public void setNpxg_per90(double npxg_per90) {
        this.npxg_per90 = npxg_per90;
    }

    public double getNpxg_xg_assist_per_90() {
        return npxg_xg_assist_per90;
    }

    public void setNpxg_xg_assist_per_90(double npxg_xg_assist_per_90) {
        this.npxg_xg_assist_per90 = npxg_xg_assist_per_90;
    }

    public Player_stats() {
    }

    public Player_stats(int id, String player, String position, String team, String age, String club, int birth_year,
            int games, int games_starts, int minutes, double minutes_90s, int goals, int assists, int goals_pens,
            int pens_made, int pens_att, int cards_yellow, int cards_red, double goals_per90, double assists_per90,
            double goals_assists_per90, double goals_pens_90, double goals_assists_pens_per90, double xg, double npxg,
            double xg_assist, double npxg_assist, double xg_per90, double xg_assist_per90, double xg_xg_assist_per90,
            double npxg_per90, double npxg_xg_assist_per_90) {
        this.id = id;
        this.player = player;
        this.position = position;
        this.team = team;
        this.age = age;
        this.club = club;
        this.birth_year = birth_year;
        this.games = games;
        this.games_starts = games_starts;
        this.minutes = minutes;
        this.minutes_90s = minutes_90s;
        this.goals = goals;
        this.assists = assists;
        this.goals_pens = goals_pens;
        this.pens_made = pens_made;
        this.pens_att = pens_att;
        this.cards_yellow = cards_yellow;
        this.cards_red = cards_red;
        this.goals_per90 = goals_per90;
        this.assists_per90 = assists_per90;
        this.goals_assists_per90 = goals_assists_per90;
        this.goals_pens_per90 = goals_pens_90;
        this.goals_assists_pens_per90 = goals_assists_pens_per90;
        this.xg = xg;
        this.npxg = npxg;
        this.xg_assist = xg_assist;
        this.npxg_xg_assist = npxg_assist;
        this.xg_per90 = xg_per90;
        this.xg_assist_per90 = xg_assist_per90;
        this.xg_xg_assist_per90 = xg_xg_assist_per90;
        this.npxg_per90 = npxg_per90;
        this.npxg_xg_assist_per90 = npxg_xg_assist_per_90;
    }
}
