package sample.fifa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import sample.fifa.dao.Player_defenseRepository;
import sample.fifa.dao.Player_statsRepository;
import sample.fifa.entities.Player_defense;
import sample.fifa.entities.Player_stats;

@RestController
public class MyController {

    // Sample Home Page used for testing POSTMAN.
    @GetMapping("/home")
    public String home() {
        return "Welcome to the Home Page!";
    }

    @Autowired
    private Player_statsRepository stats;

    // This route is used to get all the player statistics as mentioned in
    @GetMapping("/fifa/api/v1/statistics/get-all-details")
    public List<Player_stats> getStats() {
        return (List<Player_stats>) stats.findAll();
    }

    // This route is used to get a specific player by their player ID. The Player ID
    // has to be passed in the route.
    @GetMapping("fifa/api/v1/statistics/get-by-id/{id}")
    public Player_stats getPlayer_statsById(@PathVariable(value = "id") int id) {
        return stats.findById(id);
    }

    @Autowired
    private Player_defenseRepository defense;

    // Since there are 829 entries in the database, it shows an internal error on
    // POSTMAN when this mapping is run.
    @GetMapping("/fifa/api/v1/defense/get-all-details")
    public List<Player_defense> getDefenses() {
        return (List<Player_defense>) defense.findAll();
    }

    // Returns the football player's defence entry based on the ID passed in the
    // route.
    @GetMapping("/fifa/api/v1/defense/get-by-id/{id}")
    public Player_defense getPlayer_defenseById(@PathVariable(value = "id") int id) {
        return defense.findById(id);
    }

    // A FEW SAMPLE QUERIES FOR PLAYER_STATISTICS based on no. of goals scored and
    // no. of games played.
    // -------------------------------------------------------------

    // This Route will filter all the players who have scored more than a certain
    // number of goals. This number of goals can be passed in the URL/Route
    @GetMapping("/fifa/api/v1/statistics/apply-filter/goals/{goals}")
    public List<Player_stats> getByFilterGoals(@PathVariable(value = "goals") int goals) {
        List<Player_stats> players = stats.findByGoalsGreaterThanEqual(goals);
        return players;
    }

    // // This Route will filter all the players who have played more(or equal) than
    // // 5 games.
    @GetMapping("/fifa/api/v1/statistics/apply-filter/games")
    public List<Player_stats> getByFilterGames() {
        List<Player_stats> players = stats.findByGamesGreaterThanEqual(5);
        return players;
    }

    // A FEW SAMPLE QUERIES FOR PLAYER_DEFENCE based on position, team, tackles and
    // tackles won

    // This returns players who have done 4 tackles in their game.
    @GetMapping("/fifa/api/v1/statistics/apply-filter/tackles")
    public List<Player_defense> getByTackles() {
        List<Player_defense> players = defense.findByTackles(4);
        return players;
    }

    // --------------------------------------------------------------

    // The queries below seem to be showing 500 Internal Status Error. I tried
    // debugging for quite a long time, but could not find the bug.

    // --------------------------------------------------------------
    // This returns the players who have won 5 or more tackles.
    // @GetMapping("/fifa/api/v1/statistics/apply-filter/tackles-won")
    // public List<Player_defense> getByTacklesWon() {
    // List<Player_defense> players = defense.findByTackles_wonGreaterThanEqual(5);
    // return players;
    // }

    // This returns the players based on the position. Now, when we pass the route
    // to POSTMAN, it crashes. This may be due to too many entries being present in
    // our database.
    // @GetMapping("/fifa/api/v1/defense/apply-filter/position/{pos}")
    // public List<Player_defense> getByFilterPosition(@PathVariable(value = "pos")
    // String pos) {
    // List<Player_defense> players = defense.findByPosition(pos);
    // return players;
    // }

    // @GetMapping("/fifa/api/v1/defense/apply-filter/team/{team}")
    // public List<Player_defense> getByTeam(@PathVariable(value = "team") String
    // team) {
    // List<Player_defense> players = defense.findByTeam(team);
    // return players;
    // }

}